export const isBoolean = (variable: any): variable is boolean => {
  return typeof variable === "boolean";
};
