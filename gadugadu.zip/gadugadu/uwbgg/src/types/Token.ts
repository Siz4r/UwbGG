export interface Token {
  accessToken: string;
}
