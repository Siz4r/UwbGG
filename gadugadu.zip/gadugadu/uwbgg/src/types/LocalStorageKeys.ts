export enum LocalStorageKeys {
  ACCESS_TOKEN = "ACCESS_TOKEN",
}
