import { Conversation } from "../../store/Conversations/types";
import { UserData } from "./types";

export type ChatRowEntity = UserData | Conversation;

const DATA: ChatRowEntity[] = [];

export const Chats = () => {};
