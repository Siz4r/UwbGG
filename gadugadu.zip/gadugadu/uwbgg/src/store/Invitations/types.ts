export interface Invitation {
  id: string;
  senderNick: string;
  sendDate: Date;
}