export interface Friend {
    id: string,
    nick: string,
    firstName: string,
    lastName: string,
}