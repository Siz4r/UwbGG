package com.example.uwbggbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UwbggbackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(UwbggbackendApplication.class, args);
	}

}
