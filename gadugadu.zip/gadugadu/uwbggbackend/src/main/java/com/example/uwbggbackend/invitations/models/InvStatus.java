package com.example.uwbggbackend.invitations.models;

public enum InvStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
