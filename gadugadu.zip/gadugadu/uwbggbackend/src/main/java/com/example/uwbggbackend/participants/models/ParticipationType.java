package com.example.uwbggbackend.participants.models;

public enum ParticipationType {
    ADMIN, NORMAL
}
